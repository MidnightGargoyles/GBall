package GBall;

import server.World;

public class GBMain {
    public static void  main(String[] argc) {
    	World.getInstance().process();
    }
}